# Practice manuscript for Week 3, Lab 4

`draft_for_review.docx` is a short, fictional manuscript in Word. It is about the carbon example
from Week 2: the CH-Dav flux tower, 2006–2014. Its author does not exist. It is not a real study.

The manuscript has problems of different types, as real drafts do. Your review panel tries to
find them. Then the instructor shows the full list. Do not read the file closely before the panel
runs. The test is what the panel finds, not what you know.

Put this folder in your `carbon-example` project. The reviewers read a text copy of the Word file,
`draft_for_review.txt`. The word-text skill of the writing kit makes this copy. The methods
reviewer compares the numbers in the draft with your own `outputs/` from Week 2. If you do not
have an `outputs/` folder, use `reference_outputs/`. This folder has the results of the Week 2
example from the reference run of the instructor: the calibration on NEE, and the calibration on
GPP and RECO.

The manuscript is fictional, and the data are public (FLUXNET2015, CC BY 4.0). Thus you can use
it with Claude. Do not do this with a manuscript that someone sent you to review.
