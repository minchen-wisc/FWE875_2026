# FWE 875 Practice Call: Small Research Grants (fictional)

This call is fictional. It is for practice in F&W ECOL 875, Week 3, Lab 6. Its review criteria
are modelled on the NSF merit review criteria (NSF PAPPG 24-1, chapter III), in our own words.

- **Due:** 1 December 2026, 5:00 p.m. Central Time.
- **Award:** at most USD 20,000, for one year. One graduate student may apply.
- **Data:** projects use public data, or new data that the project will share openly.

## What to submit

1. **Project Summary.** At most 300 words. Three parts, each with its label: *Overview*,
   *Intellectual Merit*, and *Broader Impacts*. Write for scientists in other fields.
2. **Project Description.** At most 1,500 words. It must include:
   - the research question or questions, and testable hypotheses;
   - the approach, with the data sources;
   - a timeline with milestones, and how you will know that the project succeeded;
   - a section headed *Broader Impacts*, with named audiences or partners, activities, a timeline,
     and measures of success;
   - a paragraph on *Data Management and Sharing*: what data and code the project makes, where
     they will be shared, and when;
   - a statement on the *Use of Generative AI*: whether and how you used generative AI tools to
     prepare the proposal.
3. **Budget Justification.** At most 150 words. Each cost must match an activity in the
   Project Description.

## Review criteria

Reviewers judge two criteria: **Intellectual Merit** (the potential to advance knowledge) and
**Broader Impacts** (the potential to benefit society). For both criteria, reviewers ask:

1. What is the potential to advance knowledge (Intellectual Merit), or to benefit society
   (Broader Impacts)?
2. Are the ideas creative, original, or potentially transformative?
3. Is the plan well reasoned and well organized? Does it include a way to assess success?
4. Is the applicant qualified to do the work?
5. Are the resources adequate?

Both criteria get full consideration. Proposals that do not include the required parts are
returned without review.
