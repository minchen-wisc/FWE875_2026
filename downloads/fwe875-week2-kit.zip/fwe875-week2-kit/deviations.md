# Deviations from the analysis plan

| Date | What changed | Why | Who decided (me, my advisor, Claude suggested and I agreed) | Review log ID |
|---|---|---|---|---|
| | | | | |
