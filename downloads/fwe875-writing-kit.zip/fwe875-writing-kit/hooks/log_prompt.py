#!/usr/bin/env python3
"""UserPromptSubmit hook: append every prompt you send to prompt-log.jsonl in the project.
It prints nothing, because anything this hook prints is added to Claude's context.
It reads its input as UTF-8 bytes, so symbols such as m⁻² and °C are kept on Windows too."""
import json, os, sys, datetime
event = json.loads(sys.stdin.buffer.read().decode("utf-8"))
root = os.environ.get("CLAUDE_PROJECT_DIR", event.get("cwd", "."))
entry = {
    "time": datetime.datetime.now().isoformat(timespec="seconds"),
    "session": event.get("session_id"),
    "prompt": event.get("prompt"),
}
with open(os.path.join(root, "prompt-log.jsonl"), "a", encoding="utf-8") as f:
    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
sys.exit(0)
