# Literature notes

One note per paper, named with the paper's key (for example `abatzoglou2016.md`). Start from `90_Templates/literature-note.md`.

Rows in the evidence ledger need a locator (page or section) and a short quote you have found in the PDF yourself.
