# A real paper with an open review: Zielis et al.

Used in Week 3, Lab 4 (a real review). Download the two PDFs in Lab 4, step 1.

The paper uses eddy covariance data from the same forest as the carbon example (Davos, CH-Dav),
for 1997–2011. The journal *Biogeosciences* publishes three things: the first version of each
paper (the discussion paper), the reports of the referees, and the replies of the authors. Thus
you can see what real referees said, and how the paper changed.

All files are open access, with a Creative Commons Attribution license (CC BY 3.0).

## Download into this folder

1. The discussion paper (2013), the version the referees reviewed. Save it here as
   `zielis2013_discussion.pdf`:
   https://bg.copernicus.org/preprints/10/15587/2013/bgd-10-15587-2013.pdf
2. The final paper (2014). Save it here as `zielis2014_final.pdf`:
   https://bg.copernicus.org/articles/11/1627/2014/bg-11-1627-2014.pdf

## Read in your browser (Lab 4)

- The review page, with every report and reply:
  https://bg.copernicus.org/articles/11/1627/2014/bg-11-1627-2014-discussion.html
- Referee 1: https://bg.copernicus.org/preprints/10/C5805/2013/bgd-10-C5805-2013.pdf
- Referee 2: https://bg.copernicus.org/preprints/10/C5894/2013/bgd-10-C5894-2013.pdf
- Authors' reply to Referee 1: https://bg.copernicus.org/preprints/10/C7590/2013/bgd-10-C7590-2013.pdf
- Authors' reply to Referee 2: https://bg.copernicus.org/preprints/10/C7595/2013/bgd-10-C7595-2013.pdf

## Citations

Zielis, S., Etzold, S., Zweifel, R., Eugster, W., Haeni, M., and Buchmann, N.: Forest NEP is
significantly driven by previous year's weather, Biogeosciences Discussions, 10, 15587–15611, 2013.

Zielis, S., Etzold, S., Zweifel, R., Eugster, W., Haeni, M., and Buchmann, N.: NEP of a Swiss
subalpine forest is significantly driven not only by current but also by previous year's weather,
Biogeosciences, 11, 1627–1635, https://doi.org/10.5194/bg-11-1627-2014, 2014.
