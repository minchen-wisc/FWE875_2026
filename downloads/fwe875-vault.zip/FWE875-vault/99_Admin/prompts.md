# Prompts I reuse

Copy the course prompts here as you use them, then edit them into your own versions. Note which version worked and why.
