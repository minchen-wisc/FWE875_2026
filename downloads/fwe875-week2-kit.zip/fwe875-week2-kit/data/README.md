# Data

One section per raw file in `data/raw/`. Fill it in when the file arrives, before any analysis.
In this course, data are public (published, with a license) or a synthetic stand-in you made with the
same structure as unpublished data. Unpublished research data stay out of AI tools that aren't
UW-approved.

## <file name>
- What it is: <one sentence>
- Source: <who published it, with URL or DOI; or "synthetic, made by R/make_synthetic.R">
- Citation: <how to cite it, with version>
- License: <e.g., CC BY 4.0, CC0, or the data portal's terms of use>
- May be shared with my partner and on a private GitHub repository: <yes / no, and why>
- Obtained: <date>, by <download script name, or "copied by hand from ...">
- SHA-256: <checksum>
- Size and shape: <rows × columns, or raster dimensions and resolution>
- Known caveats: <provisional values, gaps, calendar, scale factors, coordinate system...>

Get a checksum:
- macOS: `shasum -a 256 data/raw/<file>`
- Windows PowerShell: `Get-FileHash data\raw\<file> -Algorithm SHA256`

If a file is too large for GitHub (over about 50 MB), list it in `.gitignore`, keep this section, and say
here exactly how someone else gets the file.
