"""Fire-season VPD and burned area: version 1.

Reads the raw data, fits the model, bootstraps a confidence interval, and makes Figure 1.
"""
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import statsmodels.formula.api as smf

d = pd.read_csv("data/raw/fire_regions_class_dataset.csv.gz")

# Make sure year is numeric
d["year"] = pd.to_numeric(d["year"], errors="coerce")

# -9999 means no burned area was recorded that season
d.loc[d["burned_area_ha"] == -9999, "burned_area_ha"] = 0

# Remove incomplete rows
d = d.dropna(subset=["year", "fs_vpd_kpa", "burned_area_ha"])

# log1p so that seasons with zero burned area are kept
d["log_ba"] = np.log1p(d["burned_area_ha"])

# Linear model of log burned area on VPD
model = smf.ols("log_ba ~ fs_vpd_kpa", data=d).fit()
slope = model.params["fs_vpd_kpa"]

# Bootstrap 95% confidence interval for the slope
boot = []
for i in range(500):
    s = d.sample(len(d), replace=True)
    boot.append(smf.ols("log_ba ~ fs_vpd_kpa", data=s).fit().params["fs_vpd_kpa"])
ci_low, ci_high = np.percentile(boot, [2.5, 97.5])

os.makedirs("outputs", exist_ok=True)
pd.DataFrame({
    "term": ["fs_vpd_kpa"],
    "slope": [slope],
    "ci_low": [ci_low],
    "ci_high": [ci_high],
    "r2": [model.rsquared],
    "n": [len(d)],
}).to_csv("outputs/results.csv", index=False)

# Figure 1: remove extreme values so the main pattern is visible
plot_d = d[d["burned_area_ha"] < d["burned_area_ha"].quantile(0.99)]
codes = plot_d["region_id"].astype("category").cat.codes

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.scatter(plot_d["fs_vpd_kpa"], np.log10(plot_d["burned_area_ha"] + 1), c=codes, cmap="viridis", s=25)
x = np.linspace(d["fs_vpd_kpa"].min(), d["fs_vpd_kpa"].max(), 50)
ax.plot(x, (model.params["Intercept"] + slope * x) / np.log(10), color="black")
ax.set_xlabel("Fire-season VPD (kPa)")
ax.set_ylabel("Burned area (ha)")
ax.set_title("VPD drives burned area")
fig.tight_layout()
fig.savefig("outputs/figure1.png", dpi=120)

print(f"Slope {slope:.3f} (95% CI {ci_low:.3f} to {ci_high:.3f}), n = {len(d)}")
