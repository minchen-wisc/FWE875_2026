# Data

One section per raw file in `data/raw/`. In this course, data are public (published, with a license)
or a synthetic stand-in. This example uses public flux tower data.

## CH-Dav_FLUXNET2015_DD_1997-2014_subset.csv
- What it is: daily eddy covariance fluxes and weather for CH-Dav (Davos, Switzerland; 46.8153 N,
  9.8559 E; 1639 m; evergreen needleleaf forest, mainly Norway spruce), 1997-2014.
- Source: the FLUXNET2015 dataset, FULLSET daily file for CH-Dav, version 1-3
  (`FLX_CH-Dav_FLUXNET2015_FULLSET_DD_1997-2014_1-3.csv`). Site data DOI: https://doi.org/10.18140/FLX/1440132
  (principal investigator: Nina Buchmann, ETH Zurich).
- Citation: Pastorello, G., et al. (2020). The FLUXNET2015 dataset and the ONEFlux processing pipeline
  for eddy covariance data. Scientific Data 7, 225. https://doi.org/10.1038/s41597-020-0534-3 ;
  and the site DOI above.
- License: CC BY 4.0 (FLUXNET2015 Tier One). Sharing and adapting are allowed with attribution.
- Changes from the original: 15 of the file's 334 columns kept (the names in the data dictionary in
  `CLAUDE.md`); rows and values unchanged.
- How obtained: the course instructor took the columns from a copy of the FLUXNET2015 file distributed
  with the Applied Geodata Science book (https://github.com/geco-bern/agds_book, folder `book/data/`),
  on 2026-10-13. The official file is available from https://fluxnet.org (download form).
- May be shared with a partner and on a private GitHub repository: yes (CC BY 4.0), with the citation.
- SHA-256: 401532ffb5fa8c9425c6ecf81dab9cf3af774d0a2b43d2a116643e23987fdf9f
- Size and shape: 6,574 rows (one per day) x 15 columns; 634 KB.
- Known caveats: values are gap-filled where measurements were missing (the `_QC` columns give the
  fraction measured or well gap-filled); GPP and RECO are not measured but partitioned from NEE with a
  model; VPD is in hPa; timestamps are local standard time.

Get a checksum:
- macOS: `shasum -a 256 data/raw/<file>`
- Windows PowerShell: `Get-FileHash data\raw\<file> -Algorithm SHA256`
