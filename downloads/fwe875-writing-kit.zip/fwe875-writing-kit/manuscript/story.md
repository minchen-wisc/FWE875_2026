# My story

Write this before the draft, without AI. Answer each question in one or two sentences.
These answers are your plan for the draft. In Lab 1 you compare them with what Claude
reads in your draft.

## Opening: what larger problem does this work help with, and who cares about it?


## Challenge: what exactly is not known? Write your question as "To learn X, we did Y."


## Action: what are your two or three key results? Give the size of each, with units.


## Resolution: what do these results mean for the problem in the opening?


## My main message, in two sentences


## Reader and journal: who will read this, and where will I submit it?

