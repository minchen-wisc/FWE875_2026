# Audience card (Week 4, Lab 2)

Pair: ____________________ and ____________________

## The paper

- Citation:
- DOI link:
- License (look on the article page): CC BY / other: ____________
- Pages: ______   Main figures: ______

## The audience (both partners use this card)

- Type: academic / industry (a decision-maker) / public
- Exactly who is in the audience (for example, "the planning team of a city water utility"):
- What they decide, or what they care about:
- What they already know:
- Setting: a 5-minute talk, then one question

## Roles (flip a coin)

- Builds the deck with Claude: ____________________
- Builds the deck by hand: ____________________

## Order of the talks (your instructor tells you)

- First talk: ____________________

Do not tell the class who used Claude until the class has rated both talks.
