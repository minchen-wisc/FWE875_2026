# Practice proposal for Week 3, Lab 6

`practice_call.md` is a fictional call for small research grants. Its review criteria are modelled
on the NSF merit review criteria. `practice_proposal.docx` is a fictional proposal, in Word, that
answers this call. The applicant does not exist.

The proposal has problems of different types, as real drafts do: missing parts, claims with no
support, risks with no plan, and parts that do not agree with each other. The `proposal-check`
skill of the writing kit tries to find them. Then the instructor shows the full list.

Run the skill from your `carbon-example` project:

    /proposal-check proposal/practice_proposal.docx proposal/practice_call.md

The proposal is fictional, so you can use it with Claude. Use the skill on your own proposals
only. Never use it on a proposal that someone sent you to review.
