---
type: project
status: active
---

# Class project: fire-season aridity and burned area

## Question we are reading for

How much of the year-to-year variation in burned area does fire-season aridity, measured as vapor pressure deficit (VPD), explain, and does that relationship hold across regions?

## Why I am reading each paper (one sentence each, written before reading)

- abatzoglou2016:
- li2023:
- rabin2017:

## Gap statement (three sentences, mine, written before asking Claude)

1.
2.
3.

## Research question

- Version 1:
- Hypothesis (with a direction):
- Version 2 (after the critique):
- The change that mattered most, and where it came from:
- Novelty scan (after Week 1, optional): the closest studies, and what changed because of them:
