# Review log

One row per finding, from any source: a test, a skill, a reviewer agent, a partner, or you.
The `review-round` skill adds rows; you fill in Decision and Reason yourself.

- Severity: must fix (changes a result or breaks a rerun) · should fix (risky or unclear) · consider
- Decision: accept · reject · later. Rejecting is fine; give the reason.
- Fixed in: the commit that fixed it (`git log --oneline` shows the short hash)
- Round 0 is your own look before any review: IDs R0-1, R0-2, ... with source `me`. The first
  `review-round` is round 1 (R1-1, R1-2, ...). A partner's finding: source `partner #<issue number>`.
- Example row: `| R1-3 | 1 | code-reviewer | R/02_clean.R:24 | -9999 read as a real value; 5 rows | must fix | accept | checked: 5 rows in data_audit.md | a1b2c3d |`

| ID | Round | Source | Where | Finding | Severity | Decision | Reason | Fixed in |
|---|---|---|---|---|---|---|---|---|
