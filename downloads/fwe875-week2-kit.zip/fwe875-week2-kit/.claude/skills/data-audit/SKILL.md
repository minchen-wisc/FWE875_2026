---
name: data-audit
description: Audit raw data against the data dictionary in CLAUDE.md before any analysis - units and ranges, identifiers, missing-value codes, dates and times, duplicates, how observations are grouped, and coverage in space and time. Use when a file is added to data/raw/, when asked whether the data are ready, or before fitting a model. Reports problems with evidence; never changes the data.
---

# Data audit

You check raw data before anyone analyzes it. You report; you never fix.

## Before you start
1. Read `CLAUDE.md`: the data dictionary, the structure, and the language (R or Python).
2. Read `data/README.md` for known caveats.
3. Never edit, move, or overwrite anything in `data/raw/`. Never drop rows, impute, or recode.
4. Never read a large file whole. Write and run short code in the project's language that prints
   summaries. Save the code as `R/audit_data.R` or `py/audit_data.py` so the audit can be rerun.

## Checks (run every one that applies to these data)

**All data**
1. Shape and types: dimensions, the type of each column or band, and whether each type is what the
   dictionary says (numbers read as text often mean a stray code or symbol).
2. Units and ranges: min, max, and quantiles of every numeric field against the dictionary's range.
   Split by source, site, instrument, and period: a subset on a different scale (about 10, 100, or
   1000 times larger, or Fahrenheit among Celsius) is a unit problem, not an outlier.
3. Missing values: NA counts per field, and sentinel codes (-9999, -999, 9999, 0 where impossible,
   "NA" or "" text). Report each code and the rows that carry it.
4. Identifiers: each ID should map to one name, one location, and one value of every attribute that
   belongs to the unit. Count rows per ID; compare with the expected count.
5. Duplicates: exact duplicate rows, and duplicate keys (same ID and time).
6. Structure: how observations are grouped (repeated measures, nesting, time series). Name the unit
   of replication. Warn if an analysis would treat grouped rows as independent.
7. Notes and flags: free-text notes or quality flags that explain values.

**Time series and dates** (if present)
8. One date format; time zone and daylight saving stated; gaps and repeated timestamps; calendar
   (365-day model calendars, leap years); aggregation windows (water year, season labels).

**Rasters and imagery** (if present)
9. Coordinate reference system and resolution match across layers; scale factor and offset applied
   (e.g., stored integers × 0.0001); nodata and fill values; cloud or quality masks; pixel area if the
   grid is in degrees.

**Point and occurrence records** (if present)
10. Coordinates inside the study area; latitude and longitude not swapped; precision and datum;
    duplicates at the same place and time; names standardized (taxonomy, site names).

**Model output** (if present)
11. Variable names and units per model or run; spin-up years excluded; members of an ensemble are
    not independent replicates; grids and time steps aligned.

## Report
Write `data_audit.md`:

| Check | Result (PASS / PROBLEM / CANNOT TELL) | Where (rows, IDs, dates, layers) | Evidence (the numbers) | Suggested fix |
|---|---|---|---|---|

Then "Questions for the researcher": one line each, for things only they can answer.
Finish with a two-line summary in the conversation: how many PROBLEM rows, and the most serious one.
