# Fire-season VPD and burned area (version 1)

VPD drives burned area across all 10 fire regions: burned area rises by 0.21 log units per kPa.

## Run

    cd ~/Desktop/fire
    Rscript analysis.R

Outputs go to `outputs/`: `results.csv`, `figure1.png`, and the caption in `figure1_caption.md`.
