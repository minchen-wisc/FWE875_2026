# Project: Fire-season aridity and burned area in ten fire regions

## What this project is
How much of the year-to-year variation in burned area does fire-season vapor pressure deficit (VPD)
explain, and does that hold across regions? The data are 20 fire seasons (2001–2020) in each of ten
fire regions (synthetic class data).

## Data
- `data/raw/fire_regions_class_dataset.csv.gz` is the original file, a gzip-compressed CSV (200 rows). Never edit it.
- Data dictionary:

| Name | Meaning | Units | Allowed range or values | Missing-value code | Notes |
|---|---|---|---|---|---|
| row_id | row number | — | 1–200 | — | |
| region_id | fire region | — | R01–R10, one per region | — | |
| region_name | fire region name | — | ten names | — | |
| biome | dominant biome of the region | — | forest, woodland, shrubland, grassland | — | |
| centroid_lat, centroid_lon | region centroid | decimal degrees | | — | |
| year | fire season | — | 2001–2020 | — | |
| data_source | where the VPD value came from | — | gridded product, station network | — | |
| fs_vpd_kpa | fire-season mean vapor pressure deficit | kPa | 0–6 | — | |
| fs_precip_mm | fire-season precipitation | mm | 0 or more | — | |
| burned_area_ha | area burned in the region that season | ha | 0 or more | -9999 | see notes |
| notes | data notes | — | free text | — | |

- Structure: 20 seasons within each of 10 regions. Regions are the unit of replication for
  between-region questions; seasons within a region are repeated measurements.

## Rules
- Use paths relative to the project root. Set random seeds.
- Never drop or replace data silently.
