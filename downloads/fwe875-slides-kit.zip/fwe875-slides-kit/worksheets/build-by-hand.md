# Build the deck by hand (Week 4, Lab 2)

You make your deck without AI. Your partner makes a deck about the same paper, for the same
audience, with Claude. Each of you has 30 minutes.

## No AI

- Close Claude and all other AI chat tools.
- Do not use Microsoft Copilot or the Designer suggestions in PowerPoint, Gemini in Google
  Slides, or Apple Intelligence in Keynote.
- Do not use an image generator.
- Spelling check is allowed.
- Use PowerPoint, Keynote, or Google Slides, with any template.

## The same rules as your partner

- 5 to 7 slides for 5 minutes.
- Each title is a full sentence that states a claim.
- Each slide shows one piece of evidence: a figure, a simple table, or one number. Not a list
  of bullets.
- Text 24 pt or larger.
- A plain style: a white background, dark text, and one sans-serif font.
- Use the figures of the paper unchanged. You can crop a figure.
- Put a credit line under each figure: authors, year, journal, figure number, license, and a
  link to the license. Example: "Sharma et al. 2016, Sci. Rep., Fig. 2, CC BY 4.0
  (creativecommons.org/licenses/by/4.0), cropped".
- If the caption gives a separate credit line for part of a figure (for example a map), the
  license of the paper may not cover that part. Do not use that part.
- Use only numbers that are in the paper. Write the page of each number in the speaker notes.
- The last slide repeats your one message.
- In the speaker notes of the last slide, write: "No AI was used to make these slides."

## A plan for the 30 minutes

| Minutes | Do this |
|---|---|
| 0–8 | Read the abstract, the figures and their captions, and the conclusions. Your partner reads for the same 8 minutes, also without tools. |
| 8–13 | On paper, write your one message, the story in three sentences (And, But, Therefore), and 5 to 7 slide titles. |
| 13–25 | Make the slides. Insert the figures. Add the numbers and their pages. |
| 25–30 | Check each number against the paper. Say the talk aloud once, with a timer. |
