# FWE 875 Week 2 starter kit (read me first)

A project skeleton for an analysis of your own data that anyone can rerun, plus the skills and
reviewer agents you use in Week 2. Nothing here is specific to one field: you adapt it to your data.

## What's inside

| Path | What it is | You edit it? |
|---|---|---|
| `README.md` | How someone else reruns your project: the file your partner follows in the practice after Week 2 | Yes, as you go |
| `CLAUDE.md` | Standing instructions Claude Code reads at the start of every session: your project, your data dictionary, the rules | Yes, first |
| `analysis_plan.md` | Your question, data, model, and planned figure, written before results | Yes, before any analysis |
| `done.md` | Your "definition of done": the checks that must pass before you stop iterating | Yes |
| `review_log.md` | Every finding from every review round, with your decision and reason | Yes, each round |
| `deviations.md` | Every change from the plan: what, why, who decided | When the plan changes |
| `data/README.md` | Where each raw file came from, its license or permission, and its checksum | Yes |
| `data/raw/` | Original data, exactly as received. Never edited | You copy files in |
| `data/processed/` | Files your scripts make | No (scripts write here) |
| `R/` or `py/` | Your analysis scripts | Claude writes, you review |
| `tests/` | Tests that check data and code | Claude writes, you review |
| `outputs/` | Results tables, figures, captions | Scripts write here |
| `run_all.R`, `run_all.py` | One command that reruns everything in order | Add your scripts to it |
| `pyproject.toml` | Python package list for uv (Python users only) | Via `uv add` |
| `.claude/settings.json` | Rules Claude Code enforces: approval prompts on, no edits to `data/raw/` | Rarely |
| `.claude/skills/` | Three skills: `data-audit`, `review-round`, `repro-check` | Adapt; add your own |
| `.claude/agents/` | Three read-only reviewers: `code-reviewer`, `stats-reviewer`, `figure-reviewer` | Adapt to your field |
| `.gitignore` | Files git should not track (environments, caches, large data) | If your data are large |

Folders starting with a dot (`.claude/`, `.gitignore`) are hidden on macOS: press Cmd+Shift+. in Finder.
Windows shows them.

## Start

1. Copy everything in this folder (including the hidden `.claude/` folder and `.gitignore`) into a new,
   empty project folder, for example `Documents/fwe875/my-project/`.
2. Follow Week 2, Lab 5 on the course site. You work in the Code tab of the Claude desktop app
   (a Local session in this folder), or with `claude` in a terminal here: both read `.claude/` and
   `CLAUDE.md` from this folder.

Delete the files for the language you don't use: `py/`, `run_all.py`, and `pyproject.toml` if you
use R; `R/` and `run_all.R` if you use Python.
