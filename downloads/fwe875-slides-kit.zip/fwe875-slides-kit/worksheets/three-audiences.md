# One paper, three audiences (Week 4, Lab 1)

Paper: Sharma, S., et al. (2016). Direct observations of ice seasonality reveal changes in
climate over the past 320–570 years. *Scientific Reports* 6: 25061.
https://doi.org/10.1038/srep25061 (CC BY 4.0)

Fill in one column for each chat. Copy short phrases from Claude's plan. Then compare the
columns with your neighbor.

| | Academic (talk-academic) | Industry (talk-industry) | Public (talk-public) | No skill |
|---|---|---|---|---|
| The one message | | | | (none) |
| Title of slide 1 | | | | |
| Numbers used: how many | | | | |
| The ending or the request | | | | |
| Items marked NOT IN SOURCE | | | | (none) |

## Compare

1. What changed between the three plans? Which change would each audience notice first?
2. Did a plan say more than the paper, for example a wider place or period, or a cause?
3. Compare the deck made with a skill and the deck made without a skill, for the same audience. Are the titles claims
   or topics? How many words are on the busiest slide? Did either deck redraw or change a figure?
4. Which plan would you present? What would you change first?
