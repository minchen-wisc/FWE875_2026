# Tests

Small scripts that check the data and the code. Every test has a name that says what it checks.

- R (testthat): files named `test-<topic>.R`; run with `Rscript -e "testthat::test_dir('tests')"`.
- Python (pytest): files named `test_<topic>.py`; run with `uv run pytest -q`.

Three kinds you need in Week 2:
1. Data tests: rules from the data dictionary (ranges, units, IDs, missing codes) that must hold
   after cleaning.
2. Known-answer tests: the analysis code run on data where you know the answer, such as simulated
   data with a known effect (does the code recover it?) or a value you calculated by hand.
3. Regression tests: once a result is checked, a test that fails if it changes without a reason.
