"""Rerun the whole analysis, in order, from data/raw/ to outputs/.

Usage, from the project folder: uv run python run_all.py
Add each new script to STEPS in the order it must run.
"""
import os
import platform
import runpy
import sys
from importlib import metadata

STEPS = [
    # "py/01_clean.py",
    # "py/02_analysis.py",
    # "py/03_figure.py",
]

# Let scripts in py/ import each other (e.g., `from functions import fit_model`),
# the same way they can when run one at a time.
sys.path.insert(0, os.path.abspath("py"))
os.makedirs("outputs", exist_ok=True)
for step in STEPS:
    print(f"== Running {step}", flush=True)
    runpy.run_path(step, run_name="__main__")

# Record what this run used, so someone else can compare.
packages = sorted(f"{d.metadata['Name']}=={d.version}" for d in metadata.distributions())
with open("outputs/session_info.txt", "w") as f:
    f.write(f"Python {sys.version}\n{platform.platform()}\n\n" + "\n".join(packages) + "\n")
print("Done. Session info written to outputs/session_info.txt")
