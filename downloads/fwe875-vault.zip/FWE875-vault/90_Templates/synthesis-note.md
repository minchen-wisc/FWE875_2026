---
type: synthesis
question: REPLACE
papers: []
ai_status: not_used
---

# Synthesis: the question in one line

## The question, asked the same way of every paper

## Comparison (one column per paper; mark what can't be compared)

| | Paper A | Paper B | Paper C |
|---|---|---|---|
| Response variable and measure | | | |
| Place, period, scale | | | |
| Driver or treatment | | | |
| Validation and uncertainty | | | |

## What the papers jointly support (with evidence IDs)

## Differences of scope (not contradictions)

## Real contradictions

## What is missing, and the smallest study that would fill it
