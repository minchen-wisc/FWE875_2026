# Credits

The four skills in this kit were written for F&W ECOL 875 (UW–Madison, Fall 2026). Their
instructions are in our own words. They use ideas from the guidance and the open skills below,
with thanks. No text was copied from the skills listed.

## Guidance and research

- Assertion–evidence slides (a sentence title with visual evidence): Garner, J. K., & Alley,
  M. P. (2013), *International Journal of Engineering Education* 29(6): 1564–1579; Garner &
  Alley (2016), *IJEE* 32(1): 39–54. A critique: Farkas, D. K. (2010), University of Washington.
- Slides for researchers: Naegle, K. M. (2021), Ten simple rules for effective presentation
  slides, *PLOS Computational Biology* 17(12): e1009554; Lortie, C. J. (2017), Ten simple rules
  for short and swift presentations, *PLOS Computational Biology* 13(3): e1005373.
- Less is more on a slide (coherence and signalling): Mayer, R. E. (2008), *American
  Psychologist* 63(8): 760–769.
- One message box for each audience: COMPASS, The Message Box
  (https://www.compassscicomm.org/). The workbook is free for personal and educational use; we
  only name its five parts.
- And, But, Therefore: R. Olson, *Houston, We Have a Narrative* (University of Chicago Press,
  2015). Accuracy in science stories: Dahlstrom, M. F. (2014), *PNAS* 111(Suppl. 4): 13614–13620.
- Answer first for decision-makers: B. Minto, *The Pyramid Principle* (situation, complication,
  question, answer); "bottom line up front" (US Army Regulation 25-50). Decision-relevant
  information: Fischhoff, B. (2013), *PNAS* 110(Suppl. 3): 14033–14039.
- Jargon: Bullock, O. M., et al. (2019), *Public Understanding of Science* 28(7): 845–853.
- Uncertainty: van der Bles, A. M., et al. (2020), *PNAS* 117(14): 7672–7683.
- Color: Crameri, F., Shephard, G. E., & Heron, P. J. (2020), *Nature Communications* 11: 5444;
  Okabe, M., & Ito, K., Color Universal Design.
- Accessibility: Microsoft, Make your PowerPoint presentations accessible; UW–Madison Digital
  Accessibility Toolbox; UW–Madison brand guidance for presentations (24 pt or larger).
- Overgeneralization in AI summaries: Peters, U., & Chin-Yee, B. (2025), *Royal Society Open
  Science* 12: 241776.

## Open skills (ideas only)

- Gabberflast/academic-pptx-skill: sentence titles, a titles-only test of the story, a word
  limit per slide, no decorative icons.
- applied-artificial-intelligence/claude-code-toolkit (MIT): the pyramid-principle,
  scqa-framework, and plain-language skills.
- dvdsosa/scientific-writing-skills: the sciwrite-outreach skill (take-home message first,
  layers of detail).
- pedrohcgs/claude-code-my-workflow (MIT): a new checker that cannot edit (verify-claims).
- luwill/research-skills (MIT): the scholar-slides skill (mark what is missing or not verified).
- K-Dense-AI/scientific-agent-skills (MIT): the timing of short talks and the rule to keep data
  figures unchanged, from the scientific-slides skill. We do not use that skill: it needs an API
  key, sends figures to other companies, can make slides as images, and tells Claude to add the
  company's own paper to your references.

The slides themselves are made by Claude's built-in tools (Claude Slides and Anthropic's
PowerPoint skill). This kit contains no copy of them.
