# Rating form: flash talks (Week 4, Lab 2)

Use one form for each pair. Do not rate your own pair. Listen as if you are in the audience on the pair's card.

Pair: ________   Paper: ______________________   Audience: ______________________

Score each talk from 1 (poor) to 5 (excellent). A score of 3 is adequate.

| Criterion | A score of 1 | A score of 5 | Talk 1 | Talk 2 |
|---|---|---|---|---|
| 1. Message and structure | No clear point; topic titles | One take-home message in the first 30 seconds; the titles build a clear story; a clear ending | | |
| 2. Fidelity to the paper | Numbers or claims that look wrong; claims more than the paper shows | Numbers with units and context; limits stated; no cause claimed for an association | | |
| 3. Audience fit | Jargon, or the wrong level for this audience | A "so what" for this audience; terms explained; numbers made meaningful | | |
| 4. Visual evidence and design | Walls of text, decoration, figures that cannot be read or have no source | Each slide shows evidence for its title; little text; easy to read; sources credited | | |
| 5. Delivery and ownership | Reads the slides; cannot answer the question | Talks to the audience; answers the question that the slides do not answer | | |
| 6. Time | More than 30 seconds over or under 5 minutes | 4:45 to 5:00; time in proportion to importance | | |

My take-home message from Talk 1, in one sentence:

My take-home message from Talk 2, in one sentence:

One thing to keep and one thing to change:

- Talk 1:
- Talk 2:

Which talk used Claude? Talk 1 / Talk 2

How sure are you? ______ % (50 % is a guess; 100 % is certain)

What made you think so?

Which talk would you send to this audience? Talk 1 / Talk 2 / either
