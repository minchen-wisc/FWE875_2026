# Project: <short title>

## What this project is
<One paragraph, written by you: the question, the system or study area, the data, and the main figure
you want. Copy it from your project summary and update it.>

## Data
- `data/raw/` holds the original files exactly as received. NEVER edit, move, rename, or overwrite them.
- New raw files are recorded in `data/README.md` (source, citation, license, date obtained,
  SHA-256 checksum). Only public data, or a synthetic stand-in for unpublished data.
- `data/processed/` holds files that scripts make. Anything there can be regenerated.
- The data may be large. Never read a whole large file into the conversation: write and run code that
  summarizes it (dimensions, column types, ranges, missing counts, a few example rows).
- Data dictionary (one row per column, variable, or band):

| Name | Meaning | Units | Allowed range or values | Missing-value code | Notes |
|---|---|---|---|---|---|
| <site_id> | <sampling site> | — | <S01–S40> | — | <sites nested in watersheds> |
| <date> | <sampling date> | — | <2018-01-01 to 2024-12-31> | — | <local time, UTC−6> |
| <value> | <what was measured> | <units> | <range> | <e.g., -9999> | <instrument, scale factor> |

- Structure: <how observations are grouped, e.g., "repeated measurements of 40 sites over 7 years;
  sites are the unit of replication">.

## Analysis plan
- The plan is in `analysis_plan.md`. Do not change it without asking me.
- Log every change from the plan in `deviations.md`: what changed, why, and who decided.

## Rules
- Language: <R | Python>. Use paths relative to the project root; never absolute paths.
- Every step is a script in `R/` or `py/`, listed in `run_all.R` or `run_all.py` in the order it runs.
- Set random seeds and write them to the outputs.
- Write a test before changing analysis code, and run the tests before saying a task is done.
- Never invent data values, parameter values, or citations. If something is missing, ask me.
- Never drop, fill, or "fix" data silently: every filter or replacement is in a script, with a
  comment and a printed count of the rows it affects.
- Explain each statistical choice in a plain-language comment above the code that makes it.
- Do not commit, merge, tag, or push unless I ask.

## How to run
- R: rerun everything with `Rscript run_all.R`; tests with `Rscript -e "testthat::test_dir('tests')"`.
  testthat runs tests from inside `tests/`, so test files reach project files with `..`, e.g.
  `source(file.path("..", "R", "functions.R"))` and `file.path("..", "data", "processed", "<file>")`.
  To use a new package: add `library(<package>)` to `R/packages.R`, run
  `Rscript -e "renv::install('<package>')"`, then record versions with `Rscript -e "renv::snapshot()"`.
- Python: rerun everything with `uv run python run_all.py`; tests with `uv run pytest -q`;
  add a package with `uv add <name>`. Shared code lives in `py/functions.py`; scripts and tests
  import it with `from functions import ...` (run_all.py and pytest put `py/` on the import path).
  Never `import py` or `from py.functions import ...`: pytest installs a module named `py`.
- Delete the lines for the language you don't use.
