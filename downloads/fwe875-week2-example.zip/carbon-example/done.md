# Definition of done (class example)

Tick a box only when you can point to the evidence (a test name, a commit, a file, a number).

## Data
- [ ] The raw file's SHA-256 matches `data/README.md`
- [ ] `data_audit.md` exists, and every PROBLEM row has a decision in `review_log.md`
- [ ] The period (2006-2014) and the QC filter are applied in a script that prints how many days each removes

## Code and tests
- [ ] Tests for the unit conversions, the model's behaviour, and parameter recovery all pass
- [ ] `run_all` reruns everything from `data/raw/` to `outputs/` with no manual steps
- [ ] Only 2006-2010 is used for calibration (a test or a printed check shows it)

## Results
- [ ] Calibrated parameters are in `outputs/`, with any parameter at a bound flagged
- [ ] Daily, monthly, and annual metrics are reported for calibration and validation years separately
- [ ] `figure1.png` and its caption are generated from the output files; no number typed by hand
- [ ] Modelled GPP and RECO were compared with the partitioned estimates, and the comparison is discussed

## Review
- [ ] At least one review round, with a decision and a reason in every row of `review_log.md`
- [ ] Any change to the plan is recorded in `deviations.md`
- [ ] Tags `v1` and `v2` are on GitHub

## Specific to this project (add one)
- [ ] 
