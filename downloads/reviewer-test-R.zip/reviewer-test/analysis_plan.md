# Analysis plan

Written before looking at results.

## Question
Within fire regions, how does log burned area change with fire-season VPD?

## Data
- Unit of observation: one region-season. Unit of replication: region.
- Exclude seasons with missing burned area (imagery gaps); do not treat them as zero.

## Model
- Response: natural log of burned area (ha). Predictor: fire-season VPD (kPa).
- Main model: linear model with region fixed effects (a separate intercept for each region), so the
  slope comes from year-to-year variation within regions. Check: a mixed model with a random
  intercept for region should give a similar slope.
- A pooled regression that ignores regions is shown only as a contrast, never as the result.
- Uncertainty: 95% confidence interval for the within-region slope.

## Known-answer checks
1. Simulate 10 regions × 20 seasons with a within-region slope of 1.0 and confirm the model recovers it.
2. Recompute one region's mean log burned area by hand.

## Planned figure
VPD (x) against burned area (y, log scale), points colored by region, each region's within-region
line, and the pooled line dashed for contrast. Caption reports the within-region slope with its CI
and n (region-seasons and regions).
