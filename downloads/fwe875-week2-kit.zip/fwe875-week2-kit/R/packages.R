# Packages this project uses (R users).
# renv reads this file to know what to record in renv.lock. It is never run.
# When you or Claude start using a package, add a library() line here, then in the project folder run:
#   Rscript -e "renv::install('<package>')"
#   Rscript -e "renv::snapshot()"
library(testthat)
library(ggplot2)
