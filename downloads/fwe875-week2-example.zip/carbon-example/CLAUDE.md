# Project: A simple carbon flux model for a subalpine spruce forest (class example)

## What this project is
A course example. We build a small daily model of the carbon exchange of a forest: gross primary
production (GPP) from light, temperature, and air dryness, and ecosystem respiration (RECO) from
temperature. Net ecosystem exchange is NEE = RECO - GPP. We calibrate the model's four parameters on
2006-2010 and validate it on 2011-2014 against eddy covariance (flux tower) data from CH-Dav, a
Norway spruce forest at 1639 m near Davos, Switzerland (FLUXNET2015). The main figure compares
observed and modelled monthly NEE. The full plan is in `analysis_plan.md`.

## Data
- `data/raw/` holds the original files exactly as received. NEVER edit, move, rename, or overwrite them.
- Raw files are recorded in `data/README.md` (source, citation, license, date obtained, SHA-256 checksum).
  The data are public: FLUXNET2015, CC BY 4.0.
- `data/processed/` holds files that scripts make. Anything there can be regenerated.
- Never read a whole data file into the conversation: write and run code that summarizes it.
- File: `data/raw/CH-Dav_FLUXNET2015_DD_1997-2014_subset.csv`, one row per day, 1997-01-01 to 2014-12-31.
- Data dictionary (FLUXNET2015 daily "DD" variables; values are daily means unless stated):

| Name | Meaning | Units | Allowed range or values | Missing-value code | Notes |
|---|---|---|---|---|---|
| TIMESTAMP | Date | YYYYMMDD | 19970101-20141231, every day once | -9999 | Local standard time |
| TA_F | Air temperature, gap-filled | deg C | -35 to 35 | -9999 | |
| TA_F_QC | Fraction of the day's half-hours measured or good-quality gap-filled | fraction | 0 to 1 | -9999 | |
| SW_IN_F | Incoming shortwave radiation, gap-filled | W m-2 (daily mean) | 0 to 450 | -9999 | Convert to PAR in MJ m-2 d-1 (see plan) |
| SW_IN_F_QC | As TA_F_QC, for SW_IN_F | fraction | 0 to 1 | -9999 | |
| VPD_F | Vapor pressure deficit, gap-filled | hPa | 0 to 50 | -9999 | hPa, not kPa: divide by 10 for kPa |
| VPD_F_QC | As TA_F_QC, for VPD_F | fraction | 0 to 1 | -9999 | |
| P_F | Precipitation | mm d-1 (daily sum) | 0 to 200 | -9999 | Not used by the model |
| P_F_QC | As TA_F_QC, for P_F | fraction | 0 to 1 | -9999 | |
| NEE_VUT_REF | Net ecosystem exchange of CO2, gap-filled | g C m-2 d-1 | -15 to 15 | -9999 | Positive = carbon released to the air; negative = uptake |
| NEE_VUT_REF_QC | Fraction of the day's half-hours measured or good-quality gap-filled | fraction | 0 to 1 | -9999 | Low values = mostly gap-filled (modelled) |
| GPP_NT_VUT_REF | Gross primary production, night-time partitioning | g C m-2 d-1 | -5 to 20 | -9999 | Estimated from NEE with a respiration model; negative on some winter days (down to about -4), an artifact of partitioning |
| RECO_NT_VUT_REF | Ecosystem respiration, night-time partitioning | g C m-2 d-1 | 0 to 20 | -9999 | Estimated from night-time NEE and temperature |
| GPP_DT_VUT_REF | Gross primary production, daytime partitioning | g C m-2 d-1 | 0 to 20 | -9999 | Not used in version 1 |
| RECO_DT_VUT_REF | Ecosystem respiration, daytime partitioning | g C m-2 d-1 | 0 to 20 | -9999 | Not used in version 1 |

- Structure: one site, one value per day. Days are not independent (weather and the seasons carry
  over from day to day), so calibration and validation are split by whole years, never by random days.
  Results describe this one forest only.

## Analysis plan
- The plan is in `analysis_plan.md`. Do not change it without asking me.
- Log every change from the plan in `deviations.md`: what changed, why, and who decided.

## Rules
- Language: <R | Python>. Use paths relative to the project root; never absolute paths.
- Every step is a script in `R/` or `py/`, listed in `run_all.R` or `run_all.py` in the order it runs.
- The model equations live in one file of functions (`R/functions.R` or `py/functions.py`) that the
  scripts and the tests both use. Units go in a comment next to every variable and parameter.
- Set random seeds and write them to the outputs.
- Write a test before changing analysis code, and run the tests before saying a task is done.
- Never invent data values, parameter values, or citations. If something is missing, ask me.
- Never drop, fill, or "fix" data silently: every filter or replacement is in a script, with a
  comment and a printed count of the rows it affects.
- Explain each modelling and statistical choice in a plain-language comment above the code that makes it.
- Do not commit, merge, tag, or push unless I ask.

## How to run
- R: rerun everything with `Rscript run_all.R`; tests with `Rscript -e "testthat::test_dir('tests')"`.
  testthat runs tests from inside `tests/`, so test files reach project files with `..`, e.g.
  `source(file.path("..", "R", "functions.R"))` and `file.path("..", "data", "processed", "<file>")`.
  To use a new package: add `library(<package>)` to `R/packages.R`, run
  `Rscript -e "renv::install('<package>')"`, then record versions with `Rscript -e "renv::snapshot()"`.
- Python: rerun everything with `uv run python run_all.py`; tests with `uv run pytest -q`;
  add a package with `uv add <name>`. Shared code lives in `py/functions.py`; scripts and tests
  import it with `from functions import ...` (run_all.py and pytest put `py/` on the import path).
  Never `import py` or `from py.functions import ...`: pytest installs a module named `py`.
- Delete the lines for the language you don't use.
