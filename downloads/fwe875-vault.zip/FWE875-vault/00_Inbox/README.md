# Inbox

Quick captures: a link, an idea in the hallway, a figure to look at later. Sort them into a proper note within a week, or delete them.
