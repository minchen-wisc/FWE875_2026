# Source register

What each paper is, and what you (or Claude) actually had access to. "A PDF is attached" is not the same as "the whole paper was read".

| Key | Citation | DOI | License or access | Full text in Zotero? | Figures or supplements checked? |
|---|---|---|---|---|---|
| abatzoglou2016 | Abatzoglou & Williams (2016) Proceedings of the National Academy of Sciences 113(42):11770–11775 | 10.1073/pnas.1607171113 | Free to read at PNAS (not open-licensed) | | |
| li2023 | Li, Zhu, Riley, et al. (2023) Geoscientific Model Development 16(3):869–884 | 10.5194/gmd-16-869-2023 | CC BY 4.0 | | |
| rabin2017 | Rabin, Melton, Lasslop, et al. (2017) Geoscientific Model Development 10(3):1175–1197 | 10.5194/gmd-10-1175-2017 | CC BY 3.0 | | |
