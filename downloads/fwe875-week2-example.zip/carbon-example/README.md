# A simple carbon flux model for CH-Dav (FWE 875 class example)

A four-parameter daily model of gross primary production and ecosystem respiration, calibrated on
2006-2010 and validated on 2011-2014 against FLUXNET2015 eddy covariance data from CH-Dav (Davos, Switzerland).

## Rerun this analysis

These steps should work on a computer that has never seen this project. Test them by cloning into a
new folder and following them exactly.

1. Get the code: `git clone <repository URL>` and `cd <folder>`.
2. Get the data: the file is in `data/raw/`. Check it against the checksum in `data/README.md`.
3. Install the software:
   - R (<version>): in R, run `renv::restore()` to install the package versions in `renv.lock`.
   - Python: install uv, then run `uv sync` to install the versions in `uv.lock`.
4. Rerun everything: `Rscript run_all.R` or `uv run python run_all.py`.
   This writes `outputs/` and takes about <minutes> minutes.
5. Run the tests: `Rscript -e "testthat::test_dir('tests')"` or `uv run pytest -q`.

## What's where

- `analysis_plan.md`: the plan, written before results; `deviations.md`: changes from it
- `review_log.md`: problems found in review and what was done about each
- `outputs/`: <parameters, metrics, annual sums, figure, caption>

## Versions

`v1` is the first complete run; each later tag follows a review round. `git tag -n` lists them.

## Data and license

Data: FLUXNET2015, site CH-Dav (https://doi.org/10.18140/FLX/1440132), CC BY 4.0; cite Pastorello et
al. (2020), Scientific Data 7, 225. Code license: <to be chosen in Week 4>.
<A short statement of how AI was used, from your AI-use log.>
