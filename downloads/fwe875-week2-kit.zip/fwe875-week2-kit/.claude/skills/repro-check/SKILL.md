---
name: repro-check
description: Test whether the project reruns from scratch on someone else's computer - clone it into a temporary folder, follow README.md exactly, rebuild the environment, rerun everything, and compare the new outputs with the committed ones. Use before tagging a version, before sharing the repository, or when asked whether the analysis is reproducible. Reports what fails; does not fix it.
---

# Reproducibility check

You play a careful stranger who has only the repository and `README.md`. You report what breaks.
You do not fix anything in the original project.

## Steps
1. In the original project, run `git status`. If anything is uncommitted, stop and ask the
   researcher to commit: a clone only contains committed files.
2. Make a temporary folder outside the project and clone into it:
   `git clone <path to the project> <temporary folder>/rerun`. Work only in that clone from now on.
3. Follow `README.md` step by step, exactly as written. Do not use knowledge from the original
   folder. If a step is unclear or missing, note it, make the smallest reasonable guess, and go on.
4. Rebuild the environment the README describes (`renv::restore()` or `uv sync`).
5. Get the data as the README says. If raw files are not in the repository, check that the README
   says exactly how to get them, and compare checksums with `data/README.md`.
6. Rerun everything with the README's command. Record the time it took.
7. Compare outputs with the committed ones: for tables, compare values (allow differences below
   1e-8); for figures, compare file checksums and say whether they differ. List every difference.
   `outputs/session_info.txt` is expected to differ on another computer: list only the package
   versions that differ. A figure whose bytes differ while its table values match is usually a
   graphics-library difference: say so, and don't count it as a failure.
8. Also check, by reading the code: absolute paths, random numbers without a seed, files the code
   reads that are not in the repository or made by a script, and packages used but not recorded in
   `renv.lock` or `uv.lock`.

## Report
Write `repro_report.md` in the ORIGINAL project:

| Step | Result (OK / FAILED / UNCLEAR) | What happened | What the README or code needs |
|---|---|---|---|

End with one line: "Reran from a clean clone: yes / no", and the outputs that differed.
Then delete the temporary clone.

## Never
- Never edit files in the original project except `repro_report.md`.
- Never commit or push.
