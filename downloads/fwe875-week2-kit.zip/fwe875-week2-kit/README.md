# <Project title>

<Two sentences: the question and the data.>

## Rerun this analysis

These steps should work on a computer that has never seen this project. Test them by cloning into a
new folder and following them exactly.

1. Get the code: `git clone <repository URL>` and `cd <folder>`.
2. Get the data: <the files are in `data/raw/` | download <file> from <URL or DOI> into `data/raw/` | run `<script>` to download them>.
   Check the files against the checksums in `data/README.md`.
3. Install the software:
   - R (<version>): in R, run `renv::restore()` to install the package versions in `renv.lock`.
   - Python: install uv, then run `uv sync` to install the versions in `uv.lock`.
4. Rerun everything: `Rscript run_all.R` or `uv run python run_all.py`.
   This writes `outputs/` and takes about <minutes> minutes.
5. Run the tests: `Rscript -e "testthat::test_dir('tests')"` or `uv run pytest -q`.

## What's where

- `analysis_plan.md`: the plan, written before results; `deviations.md`: changes from it
- `review_log.md`: problems found in review and what was done about each
- `outputs/`: <results table, figure, caption>

## Versions

Tagged versions: `git tag -n` lists them. `v1` is the first complete run; each later tag follows a
review round.

## License and use of AI

<License for code and for text and figures; to be chosen in Week 4.>
<A short statement of how AI was used, from your AI-use log.>
