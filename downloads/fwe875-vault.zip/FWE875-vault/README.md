# FWE 875 research vault

Start here. This folder is an Obsidian vault: every note is a plain Markdown file you own.

## The rule behind the folders

Zotero keeps the sources. This vault keeps your thinking. Claude helps with one bounded task at a time, and its output stays in quarantine until you have checked it. You decide what is true.

| Folder | What goes in it | Who writes it |
|---|---|---|
| 00_Inbox | Quick captures you will sort later | You |
| 10_Sources | Annotation notes exported from Zotero. Re-exporting replaces them, so never keep your own thinking here | Zotero export |
| 20_Literature | One note per paper: what it says, the evidence, its limits, what you make of it | You |
| 30_Synthesis | Comparisons across papers and concept notes | You |
| 40_Projects | Research questions, designs, decisions | You |
| 50_Drafts | Your writing | You |
| 60_AI_Drafts | Everything Claude writes, unverified until you check it | Claude |
| 90_Templates | Note templates | Course |
| 99_Admin | Source register, prompts, AI-use log | You |

## Three things to keep separate

1. Storing a paper (Zotero) is not understanding it (your literature note).
2. Understanding a paper is not using it to support a claim (your evidence ledger, with a locator and a quote you checked).
3. Claude's output (60_AI_Drafts) is not your note. Copy a row into your own note only after you have checked it against the PDF.

## Annotation labels (start each Zotero annotation comment with one)

- [RESULT] something the paper reports
- [METHOD] data, design, model, validation, assumptions
- [LIMIT] a limitation or boundary the authors state, or one you see (say which)
- [IDEA] your own interpretation or next question; never the paper's conclusion

## Status labels used in note properties

- reading_status: to-read, reading, read
- source_coverage: metadata_only, abstract_only, selected_sections, full_text (what you actually read, not what is attached)
- ai_status: not_used, used-unverified, used-verified

CLAUDE.md tells Claude Code how to behave in this vault. It is guidance, not a lock. The locks are in .claude/settings.json (a hidden folder).
