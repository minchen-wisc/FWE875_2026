# Synthesis

Notes that compare papers or build a concept across them. A synthesis note asks one question of several papers and says where they cannot be compared. Link to the literature notes instead of copying them. Start from `90_Templates/synthesis-note.md`.
