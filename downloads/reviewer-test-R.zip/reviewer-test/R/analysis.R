# Fire-season VPD and burned area: version 1.
# Reads the raw data, fits the model, bootstraps a confidence interval, and makes Figure 1.

d <- read.csv("data/raw/fire_regions_class_dataset.csv.gz")

# Make sure year is numeric
d$year <- suppressWarnings(as.numeric(d$year))

# -9999 means no burned area was recorded that season
d$burned_area_ha[d$burned_area_ha == -9999] <- 0

# Remove incomplete rows
d <- d[complete.cases(d[, c("year", "fs_vpd_kpa", "burned_area_ha")]), ]

# log1p so that seasons with zero burned area are kept
d$log_ba <- log1p(d$burned_area_ha)

# Linear model of log burned area on VPD
model <- lm(log_ba ~ fs_vpd_kpa, data = d)
slope <- unname(coef(model)["fs_vpd_kpa"])

# Bootstrap 95% confidence interval for the slope
boot <- replicate(500, {
  s <- d[sample(nrow(d), replace = TRUE), ]
  unname(coef(lm(log_ba ~ fs_vpd_kpa, data = s))["fs_vpd_kpa"])
})
ci <- unname(quantile(boot, c(0.025, 0.975)))

dir.create("outputs", showWarnings = FALSE)
write.csv(data.frame(term = "fs_vpd_kpa", slope = slope, ci_low = ci[1], ci_high = ci[2],
                     r2 = summary(model)$r.squared, n = nrow(d)),
          "outputs/results.csv", row.names = FALSE)

# Figure 1: remove extreme values so the main pattern is visible
plot_d <- d[d$burned_area_ha < quantile(d$burned_area_ha, 0.99), ]
cols <- hcl.colors(length(unique(plot_d$region_id)), "viridis")[as.integer(factor(plot_d$region_id))]

png("outputs/figure1.png", width = 840, height = 540, res = 120)
plot(plot_d$fs_vpd_kpa, log10(plot_d$burned_area_ha + 1), col = cols, pch = 16,
     xlab = "Fire-season VPD (kPa)", ylab = "Burned area (ha)", main = "VPD drives burned area")
x <- seq(min(d$fs_vpd_kpa), max(d$fs_vpd_kpa), length.out = 50)
lines(x, (coef(model)[1] + slope * x) / log(10), lwd = 2)
dev.off()

cat(sprintf("Slope %.3f (95%% CI %.3f to %.3f), n = %d\n", slope, ci[1], ci[2], nrow(d)))
