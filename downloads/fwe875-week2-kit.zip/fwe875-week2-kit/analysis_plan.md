# Analysis plan

Written by <name> on <date>, before looking at any results. Commit this file before the first analysis.
Changes after that go in `deviations.md`, not here.

## Question
<One sentence. What relationship, difference, or pattern will you estimate?>

## Data
- Files: <which files in data/raw/>
- Unit of observation: <one row = ...>
- Unit of replication: <what is independent: sites, plots, regions, individuals, images...>
- Rows or pixels to exclude, and why: <decided now, before results>

## Variables
- Response: <name, units, any transformation and why>
- Predictor(s) of interest: <name, units>
- Other variables (covariates, grouping factors): <name and why they are in the model>

## Model
- Method: <e.g., linear mixed model with a random intercept for site>
- Why this method fits the structure of the data: <one or two sentences>
- What would change your mind about the method (e.g., a diagnostic that fails): <...>

## Known-answer checks (at least two)
Checks where you know what the right answer is, so you can tell whether the code works:
1. <e.g., simulate data with a known slope of 0.5 and confirm the analysis code recovers it>
2. <e.g., compute one site's mean by hand and compare with the script>
3. <e.g., reproduce a published value from the same data>

## How the result will be checked on data it hasn't seen
<If anything is fitted or calibrated: which data are held out (e.g., whole years, sites, or regions,
never random rows of autocorrelated data), and which metrics you will report for them. If nothing is
fitted, say so and what plays this role instead.>

## Planned figure
<What it shows: x, y, grouping, raw data or summaries, how uncertainty is shown. Attach a sketch.>

## What you will report
<The numbers that will go in the paper: estimate, uncertainty, n at the right level.>

## What would make you doubt the result
<Written now: e.g., a parameter at its bound, an effect far outside published values, a known-answer
check that fails, results that change a lot when one site or year is left out.>
