# Analysis plan: a simple carbon flux model for CH-Dav (class example)

Written before any model results, by the course instructor. Every later change goes in `deviations.md`.

## 1. Question
How well does a four-parameter model of gross primary production (GPP) and ecosystem respiration
(RECO), calibrated on 2006-2010, reproduce net ecosystem exchange (NEE) at the CH-Dav subalpine
spruce forest in the years it has not seen (2011-2014): day by day, month by month, and as annual sums?

## 2. Data
- `data/raw/CH-Dav_FLUXNET2015_DD_1997-2014_subset.csv` (see `data/README.md` and the dictionary in `CLAUDE.md`).
- Period used: 2006-2014. Reason: in this file, 2005 is mostly gap-filled (low `NEE_VUT_REF_QC`), and
  the years before it have much higher annual RECO and annual NEE near zero or positive (-107 to +264
  g C m-2), against -320 to -672 from 2006 on. Mixing the two periods would
  ask one set of parameters to fit two different-looking records. The data audit should confirm this.
- Days used to calibrate and to compute daily and monthly metrics: `NEE_VUT_REF_QC >= 0.8` (at least
  80% of the day's half-hours measured or good-quality gap-filled). Annual sums use every day.
- Calibration years: 2006-2010. Validation years: 2011-2014. Split by whole years because days are
  autocorrelated; a random split of days would make validation look better than it is.

## 3. Model (version 1)
Daily time step, driven by `TA_F`, `SW_IN_F`, and `VPD_F`:

- PAR (MJ m-2 d-1) = SW_IN_F (W m-2) x 0.0864 x 0.5
  (0.0864 converts a daily mean in W m-2 to MJ m-2 d-1; about half of shortwave radiation is
  photosynthetically active)
- VPD (kPa) = VPD_F (hPa) / 10
- f_T = min(max((TA - T_min) / (T_opt - T_min), 0), 1), with T_min = -5 deg C and T_opt = 20 deg C (fixed)
- f_D = exp(-k_D x VPD)
- GPP = epsilon x PAR x f_T x f_D
- RECO = R10 x Q10 ^ ((TA - 10) / 10)
- NEE = RECO - GPP   (FLUXNET sign convention: positive = release to the air)

| Parameter | Meaning | Units | Start | Lower bound | Upper bound |
|---|---|---|---|---|---|
| epsilon | Light-use efficiency | g C MJ-1 | 1.0 | 0 | 5 |
| k_D | Sensitivity of GPP to VPD | kPa-1 | 0.5 | 0 | 3 |
| R10 | Respiration at 10 deg C | g C m-2 d-1 | 2.0 | 0 | 10 |
| Q10 | Increase in respiration per 10 deg C | - | 2.0 | 1 | 5 |

## 4. Calibration (version 1)
- Objective: minimize the sum of squared errors of daily NEE (model minus `NEE_VUT_REF`) on the
  calibration days.
- Method: bounded least squares from the start values above (Python: `scipy.optimize.least_squares`;
  R: `optim(method = "L-BFGS-B")`).
- Report the calibrated values, and flag any parameter that ends at one of its bounds.

## 5. Validation and metrics
For the calibration and the validation years separately:
- daily NEE on the selected days: n, RMSE, mean bias (model minus observed), R2, and Nash-Sutcliffe
  efficiency NSE = 1 - sum((model - obs)^2) / sum((obs - mean(obs))^2);
- monthly mean NEE (all days): NSE;
- annual NEE sums (all days), observed and modelled, for each year 2006-2014.
- As diagnostics only: modelled GPP and RECO against `GPP_NT_VUT_REF` and `RECO_NT_VUT_REF`. These
  are not measurements: they come from a partitioning model fitted to night-time NEE.

## 6. Figure
`outputs/figure1.png`, two panels: (a) monthly mean NEE, observed and modelled, 2006-2014, with the
calibration years shaded; (b) daily NEE, observed against modelled, validation years only, with a
1:1 line. `outputs/figure1_caption.md` is written by code, with every number read from the output files.

## 7. Known-answer checks (tests, written before the model code)
1. Unit conversions: SW_IN_F = 100 W m-2 gives PAR = 4.32 MJ m-2 d-1; VPD_F = 10 hPa gives 1 kPa.
2. Model behaviour: GPP = 0 when PAR = 0 or when TA <= -5 deg C; RECO = R10 at TA = 10 deg C;
   RECO doubles from 10 to 20 deg C when Q10 = 2; NEE = RECO - GPP exactly.
3. Parameter recovery: simulate daily NEE for 2006-2010 from the real forcing with
   epsilon = 1.2, k_D = 0.8, R10 = 2.5, Q10 = 2.0, add normal noise with SD 1.0 g C m-2 d-1
   (seed 875), and calibrate. Each parameter must come back within 10% of its true value.

## 8. What would make us doubt the result
- A parameter at its bound: the data push it further than we allowed, so the fit is being made by
  the wrong part of the model.
- A parameter that means something different from what we think. Q10 fitted to a whole seasonal cycle
  of daily data is an "apparent" Q10: temperature moves together with other seasonal drivers, which the
  fit attributes to temperature. When short-term temperature responses were separated from seasonal
  ones across 60 FLUXNET sites, Q10 was about 1.4 +/- 0.1 (Mahecha et al. 2010, Science 329: 838-840,
  https://doi.org/10.1126/science.1189587). Our apparent Q10 can't be compared directly with that value.
- A large validation bias, or annual NEE off by more than the year-to-year differences we are trying to explain.
- Modelled GPP or RECO that look nothing like the partitioned estimates, even if NEE fits.

## 9. Known limitations (stated before results)
One site; no snow, soil moisture, or delayed spring recovery of photosynthesis; T_min and T_opt
fixed by assumption; partitioned GPP and RECO are model products; days are autocorrelated, so
metrics are descriptive, not significance tests.
