# Drafts

Your own writing. Claude may read these files when you ask it to review them, but it never edits them; suggestions go to 60_AI_Drafts and you apply the ones you accept.
