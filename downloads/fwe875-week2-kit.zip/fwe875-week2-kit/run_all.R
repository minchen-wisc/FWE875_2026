# Rerun the whole analysis, in order, from data/raw/ to outputs/.
# Usage, from the project folder: Rscript run_all.R
# Add one line per script, in the order the scripts must run.

steps <- character(0)
# steps <- c(steps, "R/01_clean.R")
# steps <- c(steps, "R/02_analysis.R")
# steps <- c(steps, "R/03_figure.R")

dir.create("outputs", showWarnings = FALSE)
for (s in steps) {
  message("== Running ", s)
  source(s, local = new.env(), echo = FALSE)
}

# Record what this run used, so someone else can compare.
writeLines(capture.output(sessionInfo()), "outputs/session_info.txt")
message("Done. Session info written to outputs/session_info.txt")
