# Definition of done

Write this before the first review round. You stop iterating when every box is ticked and the last
review round found no new "must fix" problems. Edit the list to fit your project; keep it short.

## Data
- [ ] `data/README.md` records every raw file: source, license or permission, date, checksum
- [ ] The `data-audit` report has no open PROBLEM rows (each one fixed in a script or explained)
- [ ] Every row or pixel removed or replaced is removed in a script that prints how many

## Code
- [ ] `run_all` reruns the whole analysis from `data/raw/` with one command
- [ ] All tests pass, including at least two known-answer checks from `analysis_plan.md`
- [ ] No absolute paths; random seeds set and recorded

## Analysis
- [ ] The model matches `analysis_plan.md`, or every difference is in `deviations.md`
- [ ] The unit of replication is right (no repeated measurements treated as independent)
- [ ] Every number I will report is in a file in `outputs/`, with its uncertainty and n

## Figure
- [ ] Shows the data, not only a summary; nothing filtered out without saying so
- [ ] Axes, units, and any transformation labelled; readable in grayscale and for color-blind readers
- [ ] Caption numbers match `outputs/`; the caption claims no more than the analysis shows

## Reproducibility
- [ ] A partner (or the `repro-check` skill) reran it from a fresh clone using only `README.md`
- [ ] Package versions recorded (`renv.lock` or `uv.lock`)
- [ ] Tagged and pushed to GitHub

## My own items
- [ ] <a check specific to your field or data>
