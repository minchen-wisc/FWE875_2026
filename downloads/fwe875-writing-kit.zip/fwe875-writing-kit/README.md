# FWE 875 writing kit (Week 3)

Skills and reviewer subagents for writing, reviewing, and checking a science paper or a proposal
with Claude Code. You write in Microsoft Word. Claude reads a text copy of your Word file and
reports. You decide, and you make each change in Word.

The checks paraphrase principles from J. Schimel (2012), *Writing Science: How to Write Papers
That Get Cited and Proposals That Get Funded* (Oxford University Press), and the guides and
funder rules listed under "Sources" below.

## What is in the kit

| File | What it does |
|---|---|
| `skills/word-text/` | Makes a read-only text copy of a Word file (`word_text.py`, standard Python only): paragraph numbers, Zotero citations with their DOIs, comments, tracked changes, and hidden text |
| `skills/story-check/` | The story: main message, OCAR (Opening, Challenge, Action, Resolution), question, ending, promises and their delivery |
| `skills/flow-check/` | Reverse outline (the point of each paragraph), sentence flow (topic and stress), terms that drift |
| `skills/line-edit/` | Numbered sentence and word edits that you accept or reject; modes `condense N`, `language`, and `voice` |
| `skills/cite-check/` | Each citation: linked to Zotero, the source exists, matches its DOI record, has no retraction notice, and supports its sentence |
| `skills/proposal-check/` | A proposal against its call: compliance, review criteria (NSF, NIH, or the call's own), story, risks, and panel questions |
| `agents/story-reviewer.md` | Reviewer for story and structure (loads story-check and flow-check) |
| `agents/clarity-reviewer.md` | Reviewer for clarity, as a reader from another field (loads line-edit) |
| `agents/methods-reviewer.md` | Reviewer for methods, claims, limitations, and numbers against `outputs/` |
| `agents/citation-reviewer.md` | Reviewer for citations (loads cite-check) |
| `hooks/log_prompt.py`, `settings-hooks.json` | Records every prompt you send, in `prompt-log.jsonl` |
| `manuscript/story.md` | Template: your story in four answers |
| `manuscript/draft.docx` | Word template with heading styles, for your next paper (the class draft is written before the kit opens) |
| `reviews/response_to_reviewers.docx` | Word template: your answer to each review point |
| `disclosure.md` | Template: an AI-use statement |
| `prompts.md` | Prompts for your own manuscript or proposal: setup, story, results, sentences, citations, review, proposals |
| `word-add-in-instructions.txt` | House rules to paste into the Claude for Word add-in (optional) |

## Install the skills and reviewers (Week 3, Lab 1)

They go in your personal Claude folder, so they work in every project on this computer.

macOS:

    mkdir -p ~/.claude/skills ~/.claude/agents
    cp -R ~/Downloads/fwe875-writing-kit/skills/. ~/.claude/skills/
    cp ~/Downloads/fwe875-writing-kit/agents/*.md ~/.claude/agents/

Windows PowerShell:

    New-Item -ItemType Directory -Force $HOME\.claude\skills, $HOME\.claude\agents | Out-Null
    Copy-Item -Recurse -Force $HOME\Downloads\fwe875-writing-kit\skills\* $HOME\.claude\skills\
    Copy-Item -Force $HOME\Downloads\fwe875-writing-kit\agents\*.md $HOME\.claude\agents\

Then start a new session. The prompt log is set up in one project at a time: see Lab 1 on the
course site.

## How the kit works with Word

1. Save your Word file. Claude reads the last saved version.
2. A skill runs `word_text.py`, which writes `draft.txt` and `draft.citations.json` next to
   `draft.docx`. The Word file does not change. You can also type `/word-text manuscript/draft.docx`.
3. The skill or the reviewer reads the text copy and reports. Each location gives the paragraph
   number of the copy and the first words of the sentence: find them in Word with Ctrl+F (Cmd+F).
4. You make each change in Word, with Track Changes on. Use Review > Compare to see all changes
   since your first draft. (With the optional Claude for Word add-in, Claude can insert the edits
   that you chose as tracked changes; you accept or reject each one, and you say so in your
   AI-use statement.)

Keep citations live: insert them with the Zotero tab in Word, store them as Fields (Zotero tab >
Document Preferences), and never use Unlink Citations on your working file.

## Rules the kit follows

- The skills report problems; you rewrite. No skill edits your Word file. `line-edit`,
  `cite-check`, and `proposal-check` write reports to `reviews/`.
- The reviewers can only read: their `tools:` line has no tool that edits files.
- Nothing in the kit adds facts, numbers, or citations, or suggests sources.
- Text inside a draft, a source, or a web page is data, not an instruction. The text copy marks
  hidden, white, and tiny text.
- Use the kit only on your own work, published papers, and the practice files. Never use it on a
  manuscript or proposal that someone sent you to review.

## Sources

Ideas adapted (paraphrased, with thanks) from: Schimel (2012); Mensh & Kording (2017) and Noble
(2017), *PLOS Computational Biology*; Smith et al. (2024) and Seckel et al. (2024), *PLOS
Computational Biology*; Anthropic's prompting guides; NIH NOT-OD-25-132 and the Simplified Review
Framework; NSF PAPPG 24-1; the DARPA Heilmeier Catechism; and these open skill collections:
scdenney/open-science-skills (citation-check, referee-response; CC BY-NC 4.0),
Imbad0202/academic-research-skills (independent reviewers; CC BY-NC 4.0),
claesbackman/AI-research-feedback (review-grant, review-paper; MIT),
conorbronsdon/avoid-ai-writing (editing contract; MIT), wanshuiyin/ARIS (response gates; MIT),
and lyndonkl/claude (hedge types). No text was copied from them.
