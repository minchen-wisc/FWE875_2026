# AI drafts (quarantine)

Everything Claude writes goes here, as new files. Treat every file here as unverified.

To use something from an AI draft: open the source, check the claim, its scope and its units, then copy it into your own note in 20_Literature or 30_Synthesis and note how you checked it. Change the draft's `ai_status` to `used-verified` only for rows you checked.
