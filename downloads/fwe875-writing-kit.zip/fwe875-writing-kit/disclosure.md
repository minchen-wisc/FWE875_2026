AI use: I used Claude (<model>, <plan>, <Claude Code with the FWE 875 writing kit / Claude for Word / chat>) on <dates> to <specific tasks, for example: diagnose the structure of my draft; suggest line edits, of which I accepted <n> of <m> and typed them myself; check my citations against Crossref and read the cited passages>. I wrote the text and made every change myself. I verified <what> by <how>. I rejected <what>. My AI-use log entries <numbers>, the prompt log, and a Word comparison with my first draft document this work. I take full responsibility for the content.

Variant for the optional Claude for Word add-in: replace "I wrote the text and made every change myself" with "I wrote the text. Claude for Word inserted <n> edits that I chose as tracked changes, and I accepted or rejected each one in Word."

Notes
- Put the statement where your journal or funder asks for it (Methods, Acknowledgments, a declaration, or the cover letter). NSF encourages a statement in the Project Description.
- Do not overstate or understate the help. Many journals do not ask authors to disclose spelling and grammar checks; check the policy.
