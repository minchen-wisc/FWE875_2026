# Sources (exported from Zotero)

Save Zotero annotation exports here, one file per paper, named with the paper's key, for example `abatzoglou2016.md`.

How to export: in Zotero, right-click the paper, choose **Add Note from Annotations**, then right-click the new note, choose **Export Note…**, pick **Markdown**, and keep **Include Zotero Links** ticked.

These files are snapshots. When you change annotations in Zotero, export again and replace the file. Never write your own thinking here: it will be lost at the next export. Write it in 20_Literature.
