---
name: review-round
description: Run one review round on the analysis - run the tests and the full pipeline, get independent reviews from the code-reviewer, stats-reviewer, and figure-reviewer subagents, and add their findings to review_log.md for the researcher to decide on. Use only when the researcher asks for a review round.
disable-model-invocation: true
---

# Review round

You organize a review. You do not fix anything and you do not decide which findings are right:
the researcher does.

## Steps
1. Run `git status`. If there are uncommitted changes, stop and ask the researcher to commit first,
   so the review is tied to one version. Record the short commit hash (`git log -1 --oneline`).
2. Read `review_log.md`. If it doesn't exist, create it with this table header and nothing else:
   `| ID | Round | Source | Where | Finding | Severity | Decision | Reason | Fixed in |` and
   `|---|---|---|---|---|---|---|---|---|`. Find the highest number in the Round column (round 0 is the
   researcher's own look). This round is that number plus one, or 1 if there are no rows.
3. Run the tests (command in `CLAUDE.md`). Record how many pass and fail, and the names of failures.
4. Rerun the whole pipeline (`run_all`, command in `CLAUDE.md`). Record whether it finished, and run
   `git status` again: list any files in `outputs/` that changed. A rerun that changes outputs
   without a code change means something is not reproducible: report it.
5. Ask the three reviewer subagents for independent reviews, at the same time:
   `code-reviewer`, `stats-reviewer`, and `figure-reviewer`. Give each only the commit hash and the
   paths it needs. Do not tell them what you or the researcher think is wrong: they should read the
   files fresh.
6. Merge the findings:
   - Number them `R<round>-1`, `R<round>-2`, ... in order of severity.
   - When two reviewers report the same problem, keep one row and list both sources.
   - Add test failures and rerun problems as findings with source `tests` or `rerun`.
   - Do not add findings that are already in `review_log.md` with a decision of reject, unless the
     reviewer gives new evidence.
7. Append one row per finding to the table in `review_log.md`, with ID, Round, Source, Where,
   Finding, and Severity. Leave Decision, Reason, and Fixed in empty.
8. In the conversation, give a short summary: counts by severity and by source, and the three most
   serious findings in one line each. Remind the researcher to fill in Decision and Reason for every
   row before asking for fixes.

## Never
- Never edit code, data, outputs, or the plan during a review round.
- Never fill in Decision or Reason.
- Never commit.
