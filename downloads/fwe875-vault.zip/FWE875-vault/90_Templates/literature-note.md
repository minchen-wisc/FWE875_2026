---
type: literature
citekey: REPLACE_WITH_KEY
reading_status: reading
source_coverage: selected_sections
figures_checked: no
ai_status: not_used
---

# Paper title (first author, year)

Source export: [[10_Sources/REPLACE_WITH_KEY]]

## My one-sentence takeaway

## Why I read it (the question it may help answer)

## Data, methods, place, period, scale

## Evidence ledger

| ID | Claim (my words) | Type | Locator (page or section) | Exact quote (under 25 words) | How I checked |
|---|---|---|---|---|---|
| E1 | | RESULT / METHOD / LIMIT | | | |

## Limitations, and what this paper does not establish

## My interpretation and a possible next step

## Connections to other notes
