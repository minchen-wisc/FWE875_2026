**Figure 1.** Fire-season vapor pressure deficit drives burned area across 10 fire regions
(n = 200 region-seasons). Burned area rises by 0.21 log units per kPa of VPD (95% CI 0.15–0.27;
R² = 0.31).
